<!DOCTYPE html>
<html>
<head>
    <title>Login Page</title>
    <link rel="stylesheet" href="css/stylelog.css">

</head>
<body>
    <form method="post" action="loginCheck.php">
    	<div class="login-page">
		<div class="form">
			<form class="register-from">

			<input type="name" name="username" placeholder="User name">



			<input type="password" name="password"placeholder="Password">



			<br><button type="submit" name="submit" value="Submit">Login</button>
			 <p>Not yet registered?</p>
			 <a href="index.php">Signup</a>
		</form>
	</div>
</div>

    </form>
</body>
</html>
